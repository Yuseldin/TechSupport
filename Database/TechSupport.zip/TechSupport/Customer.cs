﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechSupport
{
    /// <summary>
    /// Class that creates a new customer object returning a list of all their details
    /// </summary>
    public class Customer
    {
        //CUSTOMER ATTRIBUTES
        //
        private string name = null;
        private string address = null;
        private string city = null;
        private string state = null;
        private string zipcode = null;
        private string country = null;
        private string phone = null;
        private string email = null;


        //
        //CUSTOMER NAME
        /// <summary>
        /// Set the customer name
        /// </summary>
        public string Name { get; private set; }
        
        
        //
        //ADDRESS
        /// <summary>
        /// Set the customer's address
        /// </summary>
        public string Address { get; private set; }
        
        
        //
        //CITY
        /// <summary>
        /// Set the customer's city
        /// </summary>
        public string City { get; private set; }
        
        
        //
        //STATE
        /// <summary>
        /// Set the customer's state
        /// </summary>
        public string State { get; private set; }
        
        
        //
        //ZIP CODE
        /// <summary>
        /// Set the customer's zipcode
        /// </summary>
        public string Zipcode { get; private set; }
        
        
        //
        //COUNTRY
        /// <summary>
        /// Set the customer's country
        /// </summary>
        public string Country { get; private set; }
        

        //
        //PHONE
        /// <summary>
        /// Set the customer's phone number
        /// </summary>
        public string Phone { get; private set; }
        
        
        //
        //EMAIL
        /// <summary>
        /// Set the customer's email address
        /// </summary>
        public string Email { get; private set; }


        //NEW CUSTOMER
        /// <summary>
        /// Lists all the product details and pairs them with a unique key value
        /// </summary>
        public Dictionary<string, string> NewCustomer { get; private set; }



        //
        //CLASS CONSTRUCTOR
        /// <summary>
        /// Retrieve all the product's details and put them together in a dictionary that it is then passed
        /// to the NewProduct property ready to be used for further processing.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="address"></param>
        /// <param name="city"></param>
        /// <param name="state"></param>
        /// <param name="postcode"></param>
        /// <param name="country"></param>
        /// <param name="phone"></param>
        /// <param name="email"></param>
        public Customer(string name, string address, string city, string state, string postcode, string country, string phone, string email)
        {
            //The method's parameters are valued with all the class' properties values
            this.Name = name;
            this.Address = address;
            this.City = city;
            this.State = state;
            this.Zipcode = postcode;
            this.Country = country;
            this.Phone = phone;
            this.Email = email;

            //Create a dictionary to which all the product details are added and paired with a descriptive key value
            Dictionary<string, string> clientDetails = new Dictionary<string, string>();
            clientDetails.Add("Customer Name", this.Name);
            clientDetails.Add("Address", this.Address);
            clientDetails.Add("City", this.City);
            clientDetails.Add("State", this.State);
            clientDetails.Add("Post Code", this.Zipcode);
            clientDetails.Add("Country", this.Country);
            clientDetails.Add("Phone", this.Phone);
            clientDetails.Add("Email", this.Email);

            //Pass the dictionary to the NewProduct property
            NewCustomer = clientDetails;
        }


    }
}