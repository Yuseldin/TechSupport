﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechSupport
{
    /// <summary>
    /// Class that creates a new product object returning a list of all its details
    /// </summary>
    public class Product
    {
        //PRODUCT ATTRIBUTES
        //
        private string productName = null;
        private string productVersion = null;
        private string releaseDate = null;
        private string supported = null;


        //
        //PRODUCT NAME
        /// <summary>
        /// Set the product name
        /// </summary>
        public string ProductName
        {
            get { return productName; }
            private set { productName = value; }
        }


        //
        //PRODUCT VERSION
        /// <summary>
        /// Set the product version
        /// </summary>
        public string ProductVersion
        {
            get { return productVersion; }
            private set { productVersion = value; }
        }


        //
        //RELEASE DATE
        /// <summary>
        /// Set the release date for the new product
        /// </summary>
        public string ReleaseDate
        {
            get { return releaseDate; }
            private set { releaseDate = value; }
        }


        //
        //SUPPORTED
        /// <summary>
        /// Define if the product is supported or not
        /// </summary>
        public string Supported
        {
            get { return supported; }
            private set { supported = value; }
        }


        //
        //NEW PRODUCT
        /// <summary>
        /// Lists all the product details and pairs them with a unique key value
        /// </summary>
        public Dictionary<string, string> NewProduct { get; private set; }


        //
        //CLASS CONSTRUCTOR
        /// <summary>
        /// Retrieve all the product details and put them together in a dictionary that it is then passed
        /// to the NewProduct property ready to be used for further processing.
        /// </summary>
        /// <param name="prodName"></param>
        /// <param name="prodVers"></param>
        /// <param name="prodDate"></param>
        /// <param name="prodSupported"></param>
        public Product(string prodName, string prodVers, string prodDate, string prodSupported)
        {
            //The method's parameters are valued with all the class' properties values
            this.ProductName = prodName ;
            this.ProductVersion = prodVers;
            this.ReleaseDate = prodDate;
            this.Supported = prodSupported;
            
            //Create a dictionary to which all the product details are added and paired with a descriptive key value
            Dictionary<string, string> prodDetails = new Dictionary<string, string>();
            prodDetails.Add("Product Name", this.ProductName);
            prodDetails.Add("Product Version", this.ProductVersion);
            prodDetails.Add("Release Date", this.ReleaseDate);
            prodDetails.Add("Supported", this.Supported);

            //Pass the dictionary to the NewProduct property
            NewProduct = prodDetails;
        }
    }
}