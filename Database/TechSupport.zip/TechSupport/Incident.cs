﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechSupport
{
    /// <summary>
    /// Class that creates a new incident object returning a list of all their details
    /// </summary>
    public class Incident
    {
        //INCIDENT ATTRIBUTES
        //
        private string customerID = null;
        private string productID = null;
        private string techID = null;
        private string dateOpened = null;
        private string dateClosed = null;
        private string incidentTitle = null;
        private string incidentDescr = null;


        //
        //CUSTOMER ID
        /// <summary>
        /// Set the id of the customer related to the incident
        /// </summary>
        public string CustomerID { get; private set; }
        
        
        //
        //PRODUCT ID
        /// <summary>
        /// Set the id of the product that has caused the problem
        /// </summary>
        public string ProductID { get; private set; }
        
        
        //
        //TECH ID
        /// <summary>
        /// Set the id of the technician assigned to the incident
        /// </summary>
        public string TechID { get; private set; }


        //
        //DATE OPENED
        /// <summary>
        /// Set the date when the incident is created
        /// </summary>
        public string DateOpened { get; private set; }


        //
        //DATE CLOSED
        /// <summary>
        /// Set the date when the incident is resolved
        /// </summary>
        public string DateClosed { get; private set; }


        //
        //INCIDENT TITLE
        /// <summary>
        /// Set the title for the incident
        /// </summary>
        public string IncidentTitle { get; private set; }


        //
        //INCIDENT DESCRIPTION
        /// <summary>
        /// Set a brief description of the incident
        /// </summary>
        public string IncidentDescr { get; private set; }


        //
        //NEW INCIDENT
        /// <summary>
        /// Lists all the incident details and pairs them with a unique key value
        /// </summary>
        public string NewIncident { get; private set; }


        //
        //CLASS CONSTRUCTOR
        /// <summary>
        /// Retrieve all the incident's details and put them together in a dictionary that it is then passed
        /// to the NewProduct property ready to be used for further processing.
        /// </summary>
        /// <param name="customerID"></param>
        /// <param name="productID"></param>
        /// <param name="techID"></param>
        /// <param name="opened"></param>
        /// <param name="closed"></param>
        /// <param name="title"></param>
        /// <param name="descr"></param>
        public Incident(string clientId, string prodId, string techId, string opened, string closed, string title, string descr)
        {
            //The method's parameters are valued with all the class' properties values
            this.CustomerID = customerID;
            this.ProductID = address;
            this.TechID = city;
            this.DateOpened = state;
            this.DateClosed = postcode;
            this.IncidentTitle = country;
            this.IncidentDescr = phone;
            this.Email = email;

            //Create a dictionary to which all the product details are added and paired with a descriptive key value
            Dictionary<string, string> clientDetails = new Dictionary<string, string>();
            clientDetails.Add("Customer Name", this.Name);
            clientDetails.Add("Address", this.Address);
            clientDetails.Add("City", this.City);
            clientDetails.Add("State", this.State);
            clientDetails.Add("Post Code", this.Zipcode);
            clientDetails.Add("Country", this.Country);
            clientDetails.Add("Phone", this.Phone);
            clientDetails.Add("Email", this.Email);

            //Pass the dictionary to the NewProduct property
            NewCustomer = clientDetails;
        }


    }
}